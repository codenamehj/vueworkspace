<template>
    <nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="../assets/icon.png" width="30" height="30" class="d-inline-block align-top" alt="">
    게시판
  </a>
  <ul class="nav nav-pills">
      <li class="nav-item">
          <router-link class="nav-link" aria-current="page" to="/">Home</router-link>
      </li>
      <li class="nav-item">
          <router-link class="nav-link" to="/boardList">전체조회</router-link>
      </li>
      <li class="nav-item">
          <router-link class="nav-link" to="/boardForm">글 등록</router-link>
      </li>
  </ul>
</nav>
</template>