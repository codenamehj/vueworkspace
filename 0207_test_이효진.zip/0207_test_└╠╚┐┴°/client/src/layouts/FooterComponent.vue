<template>
    <p>©️ 2023 Company, Inc <img alt="logo" src="../assets/icon.png" width="50px"></p>
</template>