<template>
    <div class="container">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>제목</th>
                    <th>작성자</th>
                    <th>작성일자</th>
                    <th>댓글수</th>
                </tr>
            </thead>
            <tbody>
                <tr v-bind:key="board.no" v-for="board in boardList" @click="goToBoardInfo(board.no)">
                    <td>{{ board.no }}</td>
                    <td>{{ board.title }}</td>
                    <td v-text="board.writer" />
                    <td>{{ createdDate(board.created_date) }}</td>
                    <td>0</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>
  
<script>
import axios from 'axios'

export default {
  data() {
    return {
      boardList: []
    }
  },
  created() {
    this.getBoardList() // 비동기 작업
  },
  methods: {
    async getBoardList() { // 동기 작업
      let result = await axios.get('/api/boards').catch(err => { console.log(err) });
      let list = result.data;
      this.boardList = list;
    },
    goToBoardInfo(boardNo) {
      this.$router.push({ path: '/boardInfo', query: { "no": boardNo } });
    },
    createdDate(cDate) {
      let result = null;
      if (cDate != null) {
        let date = new Date(cDate);

        let year = date.getFullYear();
        let month = ('0' + (date.getMonth() + 1)).slice(-2);
        let day = ('0' + date.getDate()).slice(-2);

        result = year + '-' + month + '-' + day;
      }
      return result;
    }
  }
}
</script>