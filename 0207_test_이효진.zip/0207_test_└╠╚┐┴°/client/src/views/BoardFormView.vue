<template>
  <div class="container">
    <form>
      <div class="form-group">
        <label>No.</label>
        <input type="number" class="form-control" v-model="boardInfo.no" readonly>
      </div>
      <div class="form-group">
        <label>제목</label>
        <input type="text" class="form-control" v-model="boardInfo.title">
      </div>
      <div class="form-group">
        <label>작성자</label>
        <input type="text" class="form-control" v-model="boardInfo.writer">
      </div>
      <div class="form-group">
        <label>내용</label>
        <textarea class="form-control" v-model="boardInfo.content" />
      </div>
      <div class="form-group">
        <label>작성일자</label>
        <input type="date" class="form-control" v-model="boardInfo.created_date">
      </div>
      <div class="d-grid gap-2 col-6 mx-auto">
        <button type="button" class="btn btn-outline-dark" @click="saveInfo(searchNo)">저장</button>
      </div>
    </form>
  </div>
</template>
  
<script>
import axios from 'axios'

export default {
  data() {
    return {
      boardInfo: {
        no: null,
        title: "",
        writer: "",
        content: "",
        created_date: null
      },
      searchNo: null, // 등록 or 수정
    }
  },
  created() {
    this.searchNo = this.$route.query.no;
    if (this.searchNo != null && this.searchNo != undefined) {
      this.getBoardInfo();
    } else {
      this.boardInfo.created_date = this.getDate('');
    }
  },
  methods: {
    async getBoardInfo() {
      let result = await axios.get('/api/boards/' + this.searchNo).catch(err => console.log(err));
      let info = result.data;

      let newDate = this.getDate(info.created_date);
      info.created_date = newDate;

      this.boardInfo = info;
    },
    getDate(value) {
      if (value == null) return null;

      let date = value == '' ? new Date() : new Date(value);
      let year = date.getFullYear();
      let month = ('0' + (date.getMonth() + 1)).slice(-2);
      let day = ('0' + date.getDate()).slice(-2);

      return year + '-' + month + '-' + day;
    },
    saveInfo(no) { // 첫번째
      // 1) 보낼 데이터 산출
      let info = this.getSendInfo(no);

      // 2) ajax
      axios(info)
        .then(result => {
          let count = result.data.affectedRows;
          if (count == 0) {
            alert('저장되지 않았습니다. 내용을 확인해 주세요.');
          } else {
            alert('저장되었습니다.');
            if (result.data.insertId > 0) { // 등록일 경우 추가 작업
              this.boardInfo.no = result.data.insertId;
            }
          }
        })
        .catch(err => console.log(err));
    },
    getSendInfo(no) {
      // method, url, data
      let method = '';
      let url = '';
      let data = null;

      if (no == null || no == undefined) { // 등록
        method = 'post';
        url = `/api/boards`;
        data = {
          "param": {
            title: this.boardInfo.title,
            writer: this.boardInfo.writer,
            content: this.boardInfo.content,
            created_date: this.boardInfo.created_date
          }
        };
      } else { // 수정
        method = 'put';
        url = `/api/boards/${no}`;
        data = {
          "param": {
            title: this.boardInfo.title,
            writer: this.boardInfo.writer,
            content: this.boardInfo.content,
            created_date: this.boardInfo.created_date
          }
        };
      }
      return {
        method,
        url,
        data
      }
    }
  }
}
</script>