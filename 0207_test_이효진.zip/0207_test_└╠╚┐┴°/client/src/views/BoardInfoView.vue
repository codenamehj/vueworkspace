<template>
    <div class="container">
        <div class="row">
            <table class="table">
                <tbody>
                    <tr>
                        <th>번호</th>
                        <td>{{ boardInfo.no }}</td>
                        <th>작성일</th>
                        <td>{{ createdDate }}</td>
                        <th>이름</th>
                        <td>{{ boardInfo.writer }}</td>
                    </tr>
                    <tr>
                        <th colspan="2">제목</th>
                        <td colspan="4" style="text-align: justify;">{{ boardInfo.title }}</td>
                    </tr>
                    <tr>
                        <td colspan="6" height="300px" style="text-align: justify;">{{ boardInfo.content }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="d-grid gap-2 col-6 mx-auto">
            <button class="btn btn-outline-dark" @click="goToUpdate(boardInfo.no)">수정</button>
        </div>
    </div>
</template>
  
<script>
import axios from 'axios'

export default {
    data() {
        return {
            boardInfo: {}
        }
    },
    computed: {
        createdDate() {
            let result = null;
            if (this.boardInfo.created_date != null) {
                let date = new Date(this.boardInfo.created_date);

                let year = date.getFullYear();
                let month = ('0' + (date.getMonth() + 1)).slice(-2);
                let day = ('0' + date.getDate()).slice(-2);

                result = year + '-' + month + '-' + day;
            }
            return result;
        }
    },
    created() {
        let searchNo = this.$route.query.no;
        this.getBoardInfo(searchNo);
    },
    methods: {
        async getBoardInfo(boardNo) {
            let result = await axios.get('/api/boards/' + boardNo).catch(err => console.log(err));
            this.boardInfo = result.data;
        },
        goToUpdate(boardNo) {
            // 수정폼 컴포넌트 호출
            console.log(boardNo);
            this.$router.push({ path: '/boardForm', query: { "no": boardNo } });
        }
    }
}
</script>